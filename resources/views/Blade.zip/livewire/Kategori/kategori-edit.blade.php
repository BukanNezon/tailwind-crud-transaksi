<div x-data>
    <!-- Modal -->
    <div wire:ignore.self class="modal fade" id="updateModal" tabindex="-1" aria-labelledby="updateModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="updateModalLabel">Edit Kategori</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form wire:submit.prevent="kategoriUpdate">
                        <!-- Input untuk Nama Kategori -->
                        <div class="form-group mb-4">
                            <label for="name" class="fw-bold">Nama Kategori</label>
                            <input type="text" class="form-control @error('name') is-invalid @enderror" id="name" wire:model="name">
                            <!-- Pesan Error untuk Nama Kategori -->
                            @error('name')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-warning" wire:click="kategoriUpdate">Update</button>
                </div>
            </div>
        </div>
    </div>
    @push('script')
    {{-- <script>
        // gunakan variable global untuk parsing dari alpinejs
        let post_content_edit;
        ClassicEditor
            .create(document.querySelector('#content_edit'))
            .then(editor_edit  => {
                post_content_edit = editor_edit
                editor_edit.model.document.on('change:data', () => {
                    @this.set('content', editor_edit.getData());
                })
            });
    </script> --}}
    @endpush
</div>
