<div class="container mt-5 mb-5">
    <div>
        <livewire:kategori.kategori-form />
    </div>
    <div>
        <livewire:kategori.kategori-edit />
    </div>

    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Kategori</div>
                <div class="card-body">
                    <livewire:kategori.kategori-table />
                </div>
            </div>
        </div>
    </div>
</div>
