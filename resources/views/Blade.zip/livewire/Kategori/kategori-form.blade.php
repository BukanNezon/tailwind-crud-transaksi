<div x-data>
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#kategoriModal">
        Tambah Kategori
    </button>
    <br> <br>

    <!-- Modal -->
    <div wire:ignore.self class="modal fade" id="kategoriModal" tabindex="-1" aria-labelledby="kategoriModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="kategoriModalLabel">Tambah Kategori</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form wire:submit.prevent="store">
                        <!-- Input untuk Nama Kategori -->
                        <div class="form-group mb-4">
                            <label class="fw-bold">Nama Kategori</label>
                            <input id="kategoriInput" type="text" class="form-control @error('name') is-invalid @enderror" wire:model="name" placeholder="Masukkan Nama Kategori">
                            <!-- Pesan Error untuk Nama Kategori -->
                            @error('name')
                            <div class="alert alert-danger mt-2">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="submit" class="btn btn-primary" wire:click="store">Add Kategori</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        const myModal = document.getElementById('kategoriModal')
        const myInput = document.getElementById('kategoriInput')

        myModal.addEventListener('shown.bs.modal', () => {
        myInput.focus()
        })

    //     document.addEventListener('DOMContentLoaded', function() {
    //     window.addEventListener('show-post-modal', event => {
    //         $('#postModal').modal('show');
    //     });

    //     window.addEventListener('hide-modal', event => {
    //         $('#postModal').modal('hide');

    //         if (editor) {
    //             editor.setData('');
    //         }
    //     });
    // });
    </script>
</div>
