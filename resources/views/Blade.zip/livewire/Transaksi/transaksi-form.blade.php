<div class="container mt-4" x-data="{ quantityAlert: false, paymentAlert: false, successAlert: false, emptyCartAlert: false }">
    <h2 class="mb-4">Transaction Form</h2>
    
    <!-- Form transaksi -->
    <form wire:submit.prevent="saveTransaction">
        <div class="row mb-3">
            <div class="col-md-6">
                <div class="form-group">
                    <label for="customerName">Customer Name</label>
                    <input type="text" id="customerName" class="form-control" wire:model="customerName">
                    @error('customerName') <small class="text-danger">{{ $message }}</small> @enderror
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="invoice">Invoice</label>
                    <input type="text" id="invoice" class="form-control" wire:model="invoice" readonly value="{{ $invoice }}">
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="transactionDate">Transaction Date</label>
                    <input type="date" id="transactionDate" class="form-control" wire:model="transactionDate">
                    @error('transactionDate') <small class="text-danger">{{ $message }}</small> @enderror
                </div>
            </div>
            <div class="col-md-6">
                <div class="form-group">
                    <label for="product">Select Product</label>
                    <select id="product" class="form-control" wire:model="selectedProduct">
                        <option value="">Select Product</option>
                        @foreach($products as $product)
                        <option value="{{ $product->id }}" {{ $product->jumlah == 0 ? 'disabled' : '' }}>
                            {{ $product->jumlah == 0 ? 'EMPTY' : '' }} {{ $product->name }} - {{ number_format($product->harga, 2) }}
                        </option>
                        @endforeach
                    </select>
                    @error('selectedProduct') <small class="text-danger">{{ $message }}</small> @enderror
                </div>
            </div>            
            <div class="col-md-6">
                <button wire:click="addToCart" type="button" class="btn btn-primary mt-4">Add to Cart</button>
            </div>
        </div>
    </form>

    <!-- Menampilkan keranjang -->
    @if(count($cart) > 0)
        <div class="card mt-4">
            <div class="card-header">
                <h4>Cart</h4>
            </div>
            <div class="card-body">
                <table class="table table-striped table-bordered">
                    <thead>
                        <tr>
                            <th>Product</th>
                            <th>Quantity</th>
                            <th>Price</th>
                            <th>Total</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($cart as $index => $item)
                            <tr>
                                <td>{{ $item['product']->name }}</td>
                                <td>
                                    <input type="number" class="form-control" wire:model="cart.{{ $index }}.quantity" min="1" wire:change="updateQuantity({{ $index }}, $event.target.value)">
                                    <!-- Notifikasi jika quantity melebihi stok -->
                                    @if($item['quantity'] > $item['product']->jumlah)
                                        <small class="text-danger">Quantity exceeds available stock!</small>
                                    @endif
                                </td>
                                <td>{{ number_format($item['price'], 2) }}</td>
                                <td>{{ number_format($item['total'], 2) }}</td>
                                <td>
                                    <button class="btn btn-danger btn-sm" wire:click="removeItem({{ $index }})">Remove</button>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>
    @else
        <div class="alert alert-info mt-4">Cart is empty.</div>
    @endif

    <!-- Form pembayaran dan kembalian dalam tabel -->
    <div class="mt-4">
        @php
            $total = array_sum(array_column($cart, 'total'));
        @endphp
        <!-- Notifikasi jika pembayaran kurang -->
        @if ($payment < $total)
            <div class="alert alert-danger" role="alert">
                Your payment is insufficient!
            </div>
        @endif

        <h3>Payment Details</h3>
        <table class="table">
            <tbody>
                <tr>
                    <th>Payment</th>
                    <td>
                        <input type="number" id="payment" class="form-control" wire:model="payment" min="0" wire:input="calculateTotal">
                    </td>
                </tr>
                <tr>
                    <th>Change</th>
                    <td>{{ number_format($change, 2) }}</td>
                </tr>
            </tbody>
        </table>

        <!-- Notifikasi jika tidak ada transaksi di keranjang -->
        @if (count($cart) == 0)
            <div class="alert alert-danger mt-4" role="alert">
                No transactions. Cart is empty!
            </div>
        @endif

        <!-- Notifikasi jika transaksi berhasil -->
        @if (session()->has('success'))
            <div class="alert alert-success mt-4" role="alert">
                {{ session('success') }}
            </div>
        @endif

        <!-- Simpan Transaksi -->
        <button wire:click="saveTransaction" class="btn btn-success mt-4">
            Save Transaction
        </button>
        <br><br><br><br>
    </div>
</div>
