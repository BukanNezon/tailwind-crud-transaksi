<div class="container mt-4">
    <h1 class="mb-4">Transaksi</h1>
    <div class="d-flex justify-content-between mb-4">
        <div class="w-50">
            <input type="text" class="form-control" placeholder="Search transactions..." wire:model.live="search">
        </div>
        <a href="{{ route('transaksi.form') }}" class="btn btn-primary">Make Transaction</a>
    </div>

    <!-- Transaction Table -->
    <div class="table-responsive">
        <table class="table table-striped table-bordered">
            <thead class="table-dark">
                <tr>
                    <th>#</th>
                    <th>Invoice</th>
                    <th>Pelanggan</th>
                    <th>Tanggal</th>
                    <th>Total</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($transaksis as $transaksi)
                    <tr>
                        <td>{{ $transaksi->id }}</td>
                        <td>
                            <a href="#" class="text-primary" data-bs-toggle="modal" data-bs-target="#transaksiModal" 
                               wire:click="loadTransaksi({{ $transaksi->id }})">
                               {{ $transaksi->invoice }}
                            </a>
                        </td>
                        <td>{{ $transaksi->pelanggan }}</td>
                        <td>{{ \Carbon\Carbon::parse($transaksi->tanggal)->format('d-m-Y') }}</td>
                        <td>{{ number_format($transaksi->details->sum('total'), 2) }}</td>
                        <td>
                            <button class="btn btn-danger btn-sm" @click="$dispatch('transaksi-delete', { get_id: {{ $transaksi->id }} })">Delete</button>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <div class="mt-4">
        {{ $transaksis->links('pagination::bootstrap-5') }}
    </div>
    <x-transaksi-delete />

<!-- Modal for displaying transaction details -->
<div wire:ignore.self class="modal fade" id="transaksiModal" tabindex="-1" aria-labelledby="transaksiModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="transaksiModalLabel">Detail Transaksi</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                @if($selectedTransaksi)
                    <!-- Invoice and Date -->
                    <p><strong>Invoice:</strong> {{ $selectedTransaksi->invoice }}</p>
                    <p><strong>Tanggal:</strong> {{ \Carbon\Carbon::parse($selectedTransaksi->tanggal)->format('d-m-Y') }}</p>
                    
                    <!-- Loop through each product in the transaction -->
                    <table class="table table-sm">
                        <thead>
                            <tr>
                                <th>Nama Produk</th>
                                <th>Harga</th>
                                <th>Jumlah</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($selectedTransaksi->details as $detail)
                                <tr>
                                    <td>{{ $detail->product->name }}</td>
                                    <td>{{ number_format($detail->product->harga, 2) }}</td>
                                    <td>{{ $detail->qty }}</td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>

                    <!-- Payment Details -->
                    <p><strong>Pembayaran:</strong> Rp {{ number_format($selectedTransaksi->pembayaran, 2) }}</p>
                    <p><strong>Kembalian:</strong> Rp {{ number_format($selectedTransaksi->kembalian, 2) }}</p>
                    <p><strong>Total:</strong> Rp {{ number_format($selectedTransaksi->details->sum('total'), 2) }}</p>
                @endif
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>

</div>
