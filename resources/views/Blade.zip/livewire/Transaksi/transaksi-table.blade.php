<div class="container mt-4">
    <h2 class="mb-4">Transaction List</h2>
    <div class="mb-3">
        <input type="text" class="form-control" placeholder="Search..." wire:model="search">
    </div>
    <table class="table table-striped table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Invoice</th>
                <th>Pelanggan</th>
                <th>Tanggal</th>
                <th>Total</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($transaksis as $transaksi)
                <tr>
                    <td>{{ $transaksi->id }}</td>
                    <td>{{ $transaksi->invoice }}</td>
                    <td>{{ $transaksi->pelanggan }}</td>
                    <td>{{ $transaksi->tanggal->format('d-m-Y') }}</td>
                    <td>{{ number_format($transaksi->details->sum('total'), 2) }}</td>
                    <td>
                        <a href="{{ route('transaksi.edit', $transaksi->id) }}" class="btn btn-warning btn-sm">Edit</a>
                        <button class="btn btn-danger btn-sm" @click="$dispatch('transaksi-delete', { get_id: {{ $transaksi->id }} })">Delete</button>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>

    {{ $transaksis->links('pagination::bootstrap-5') }}

    <a href="{{ route('transaksi.create') }}" class="btn btn-primary">Make Transaction</a>
</div>
