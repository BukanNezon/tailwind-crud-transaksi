<div x-data>
    <!-- Button trigger modal -->
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#productModal">
        Tambah Product
    </button>
    <br> <br>

    <!-- Modal -->
    <div wire:ignore.self class="modal fade" id="productModal" tabindex="-1" aria-labelledby="productModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="productModalLabel">Tambah Product</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form wire:submit.prevent="store">
                        
                        <div class="mb-3">
                            <label for="name" class="form-label fw-bold">Nama Produk</label>
                            <input type="text" class="form-control @error('name') is-invalid @enderror" id="name" wire:model="name">
                            @error('name')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>

                    {{-- CKEditor for deskripsi --}}
                    <div wire:ignore x-data="{ deskripsi: $wire.entangle('deskripsi') }" x-init="$nextTick(() => {
                            ClassicEditor
                                .create(document.querySelector('#deskripsi'))
                                .then(editor  => {
                                    window.editorInstance = editor;
                                    editor.model.document.on('change:data', () => {
                                        @this.set('deskripsi', editor.getData());
                                    })
                                })
                        })">
                        <label for="deskripsi" class="form-label fw-bold">Deskripsi Produk</label>
                        <textarea x-model="deskripsi" class="form-control @error('deskripsi') is-invalid @enderror" id="deskripsi"
                            wire:model="deskripsi"></textarea>
                        @error('deskripsi')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                        
                    <div class="mb-3">
                        <br>
                        <label for="jumlah" class="form-label fw-bold">Jumlah Produk</label>
                        <input type="number" class="form-control @error('jumlah') is-invalid @enderror" id="jumlah" wire:model="jumlah">
                        @error('jumlah')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="harga" class="form-label fw-bold">Harga Produk</label>
                        <input type="number" class="form-control @error('harga') is-invalid @enderror" id="harga" wire:model="harga">
                        @error('harga')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="kategori" class="form-label fw-bold">Kategori</label>
                        <select id="kategori" class="form-select @error('kategori_id') is-invalid @enderror" wire:model="kategori_id">
                            <option value="">Pilih Kategori</option>
                            @foreach($categoriesList as $kategori)
                                <option value="{{ $kategori->id }}">{{ $kategori->name }}</option>
                            @endforeach
                        </select>
                        @error('kategori_id')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="image" class="form-label fw-bold">Gambar Produk</label>
                        <input type="file" class="form-control @error('image') is-invalid @enderror" id="image" wire:model="image">
                        @if ($image)
                            <img src="{{ $image->temporaryUrl() }}" class="img-thumbnail" style="width:200px" />
                        @endif
                        
                        @error('image')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>
                        <br>
                        <button type="submit" class="btn btn-primary" wire:click="store">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script>
        const myModal = document.getElementById('productModal')
        const myInput = document.getElementById('productInput')

        myModal.addEventListener('shown.bs.modal', () => {
        myInput.focus()
        })

        window.addEventListener('reset-ckeditor', event => {
            if (editorInstance) {
                editorInstance.setData('');
            }
        });

    //     document.addEventListener('DOMContentLoaded', function() {
    //     window.addEventListener('show-post-modal', event => {
    //         $('#postModal').modal('show');
    //     });

    //     window.addEventListener('hide-modal', event => {
    //         $('#postModal').modal('hide');

    //         if (editor) {
    //             editor.setData('');
    //         }
    //     });
    // });
    </script>
</div>
