<div x-data>
    <!-- Modal -->
    <div wire:ignore.self class="modal fade" id="updateModal" tabindex="-1" aria-labelledby="updateModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="updateModalLabel">Edit Product</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form wire:submit.prevent="productUpdate">
                        <div class="mb-3">
                            <label for="name" class="form-label fw-bold">Nama Produk</label>
                            <input type="text" class="form-control @error('name') is-invalid @enderror" id="name" wire:model="name">
                            @error('name')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                            @enderror
                        </div>
                        
                        {{-- Konten ( CKEDITOR ) --}}
                        <div wire:ignore x-data="{ deskripsi: $wire.entangle('deskripsi') }" wire:key="editor_edit"
                            @set-deskripsi.window="
                               product_deskripsi_edit.setData(event.detail.deskripsi)
                            "
                            >
                                <label for="deskripsi" class="form-label fw-bold">Deskripsi</label>
                                <textarea wire:model="deskripsi" x-model="deskripsi"  id="deskripsi_edit" class="form-control @error('deskripsi') is-invalid @enderror"></textarea>
                                @error('deskripsi')
                                    <div class="invalid-feedback">
                                        {{ $message }}
                                    </div>
                                @enderror
                        </div>

                    <div class="mb-3">
                        <br>
                        <label for="jumlah" class="form-label fw-bold">Jumlah Produk</label>
                        <input type="number" class="form-control @error('jumlah') is-invalid @enderror" id="jumlah" wire:model="jumlah">
                        @error('jumlah')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="harga" class="form-label fw-bold">Harga Produk</label>
                        <input type="number" class="form-control @error('harga') is-invalid @enderror" id="harga" wire:model="harga">
                        @error('harga')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>

                    <div class="mb-3">
                        <label for="kategori" class="form-label fw-bold">Kategori</label>
                        <select id="kategori" class="form-select @error('kategori_id') is-invalid @enderror" wire:model="kategori_id">
                            <option value="">Pilih Kategori</option>
                            @foreach($data_kategori as $kategori)
                                <option value="{{ $kategori->id }}">{{ $kategori->name }}</option>
                            @endforeach
                        </select>
                        @error('kategori_id')
                            <div class="invalid-feedback">
                                {{ $message }}
                            </div>
                        @enderror
                    </div>

                <!-- Input File untuk Gambar -->
                <div class="form-group mb-4">
                    <label class="fw-bold">GAMBAR</label>
                    <input wire:model="image" type="file" class="form-control @error('image') is-invalid @enderror">
                    
                    <!-- Jika ada Gambar Sebelumnya, Tampilkan -->
                    @if ($image)
                        <div class="mt-3">
                            <img src="{{ asset('storage/images/' . $image) }}" alt="Updated Image" width="100" class="d-block mb-2">

                            <!-- Nama file gambar sebelumnya -->
                            <small class="text-muted">{{ $image }}</small>
                        </div>
                    @endif



                    <!-- Pesan Error untuk Gambar -->
                    @error('image')
                    <div class="alert alert-danger mt-2">
                        {{ $message }}
                    </div>
                    @enderror
                </div>

                    <button type="submit" class="btn btn-primary" wire:click="productUpdate">Perbarui</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
    @push('script')
    <script>
        // gunakan variable global untuk parsing dari alpinejs
        let product_deskripsi_edit;
        ClassicEditor
            .create(document.querySelector('#deskripsi_edit'))
            .then(editor_edit  => {
                product_deskripsi_edit = editor_edit
                editor_edit.model.document.on('change:data', () => {
                    @this.set('deskripsi', editor_edit.getData());
                })
            });
    </script>
    @endpush
</div>
