<div>
    <table class="table table-bordered">
        <input type="search" wire:model.live="search" placeholder="Search...">
        <br>
        <br>
        <thead class="bg-dark text-white">
            <tr>
                <th scope="col">No</th>
                <th scope="col">Nama Product</th>
                <th scope="col">Deskripsi</th>
                <th scope="col">Jumlah Produk</th>
                <th scope="col">Harga</th>
                <th scope="col">Kategori</th>
                <th scope="col">Gambar</th>
                <th scope="col" style="width: 15%">Actions</th>
            </tr>
        </thead>
        <tbody>
            @forelse($products as $product)
                <tr>
                    <td>{{ $loop->iteration }}</td>
                    <td>{{ $product->name }}</td>
                    <td>{!! $product->deskripsi !!}</td>
                    <td>{{ $product->jumlah }}</td>
                    <td>{{ $product->harga }}</td>
                    <td>{{ $product->kategori->name ?? 'N/A' }}</td>
                    <td class="text-center">
                        <img src="{{ Storage::url($product->image) }}" class="rounded" style="width: 150px">
                    </td>
                    <td>
                        <button wire:click="$dispatch('productEdit', {product: {{ $product->id }}})" data-bs-toggle="modal" data-bs-target="#updateModal" class="btn btn-sm btn-warning">Update</button>
                        <button @click="$dispatch('delete-alert', {get_id: '{{ $product->id }}' })" class="btn btn-sm btn-danger">DELETE</button>
                    </td>
                </tr>
            @empty
                <tr>
                    <td colspan="8" class="text-center">Tidak Ada Produk</td>
                </tr>
            @endforelse
        </tbody>
    </table>
    <div>{{ $products->links() }}</div>
    <x-delete-alert />
</div>




{{-- <div>
    <table class="table table-bordered">
        <thead class="bg-dark text-white">
            <tr>
                <th scope="col">Image</th>
                <th scope="col">Title</th>
                <th scope="col">Content</th>
                <th scope="col" style="width: 15%">Actions</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($posts as $post)
            <tr>
                <td class="text-center">
                    <img src="{{ asset('/storage/posts/'.$post->image) }}" class="rounded" style="width: 150px">
                </td>
                <td>{{ $post->title }}</td>
                <td>{!! $post->content !!}</td>
                <td class="text-center">
                    <a href="/edit/{{ $post->id }}" wire:navigate class="btn btn-sm btn-primary">EDIT</a>
                    <button wire:click="destroy({{ $post->id }})" class="btn btn-sm btn-danger">DELETE</button>
                </td>
            </tr>
            @empty
            <div class="alert alert-danger">
                Data Post belum Tersedia.
            </div>
            @endforelse
        </tbody>
    </table>
    {{ $posts->links('vendor.pagination.bootstrap-5') }}
</div> --}}