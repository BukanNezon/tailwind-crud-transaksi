<div class="container mt-5 mb-5">
    <div>
        <livewire:product.product-form />
    </div>
    <div>
        <livewire:product.product-edit />
    </div>

    <div class="row justify-content-center">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">Product</div>
                <div class="card-body">
                    <livewire:product.product-table />
                </div>
            </div>
        </div>
    </div>
</div>
